var fs = require('fs');

    fs.readFile('.money.txt', 'utf-8', function(err,goodness){
    if (err) {
       console.log(err)
    } else {
        goodness = goodness.split('\n')
        //console.log(goodness);
        goodness.map((g) => {
            const checkArr = /(\w+)=(\w+)/;
            let newObj = {}
            //console.log(g.match(checkArr)[0])
            if(g.match(checkArr)){
                let name = g.match(checkArr)[1] 
                let val = g.match(checkArr)[2]
                newObj[name] = val
            }
            console.log(newObj)

        })
    }
});
 
